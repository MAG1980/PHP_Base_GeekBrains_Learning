<?php
$db = mysqli_connect( 'lesson5', 'test', '12345', 'test' );
