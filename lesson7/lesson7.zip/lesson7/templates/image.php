<div class="gallery__img">
	<p>Просмотров: <?= $image['likes'] ?></p>
	<img src="/gallery_img/big/<?= $image['filename'] ?>"/>

</div>
<?= $message ?>
