Добро пожаловать <?=$name?> в наш магазин!<br>
<img src="/images/01.jpg">