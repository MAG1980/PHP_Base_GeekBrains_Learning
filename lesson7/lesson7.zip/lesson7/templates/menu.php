<? //= ($_SERVER['REQUEST_URI'] != '/') ? '<p><a href=" / ">Главная</a></p>' : '' ?>
<ul class="menu">
	<li class="menu_item"><a class="menu__link" href="/">Главная</a></li>
	<li class="menu_item"><a class="menu__link" href="/catalog">Каталог</a></li>
	<li class="menu_item"><a class="menu__link" href="/about">О нас</a>
	</li>
	<li class="menu_item"><a class="menu__link" href="/gallery">Галерея</a>
	</li>
	<li class="menu_item"><a class="menu__link" href="/news">Новости</a>
	</li>
	<li class="menu_item"><a class="menu__link" href="/apicatalog">api Test</a>
	</li>
	<li class="menu_item"><a class="menu__link" href="/feedback">Отзывы</a>
	</li>
	<li class="menu_item"><a class="menu__link" href="/cart/get">Корзина</a><br>
	</li>
</ul>
