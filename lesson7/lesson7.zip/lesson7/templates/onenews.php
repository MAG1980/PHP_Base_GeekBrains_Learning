<div>
    <b><?=$news['title']?></b>
    <p><?=$news['text']?></p>
</div>